**Particles with Personality**

**Preliminary Idea**
- Particle group that starts moving really slow or not at all
- Get livelier overtime ? 
- Maybe the shape evolves or colour? Both? 

**Colour pallet**
- Dreamy
- pinks, purples, blues turns to red, yellows, oranges? 
- Black background | starts of in a dark space? 

**What shape?** 
- Spiderweb? Why spiderweb? 
- crystals? Refracting light? 
- Sound elements? 
- ~~click an alarm snooze button to change forms overtime?~~ | Click based interaction 
- **Neuron - like?**
- Jelly fish - like? 
